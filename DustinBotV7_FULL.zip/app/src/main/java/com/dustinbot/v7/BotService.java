package com.dustinbot.v7;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class BotService extends Service {
    public static final String ACTION_START="START";
    public static final String ACTION_STOP="STOP";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private Thread worker;

    enum State { WALK, ATTACK, WAIT_DEAD, LOOT }
    private State state=State.WALK;

    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && ACTION_STOP.equals(i.getAction())) stopBot();
        else if(i!=null && ACTION_START.equals(i.getAction())) startBot();
        return START_STICKY;
    }

    private void startBot(){
        if(running.getAndSet(true)) return;
        createChannel();
        startForeground(7001, new Notification.Builder(this,"dustinbot")
            .setContentTitle("DustinBot V7")
            .setContentText("Bot กำลังทำงาน")
            .setSmallIcon(android.R.drawable.ic_media_play).build());
        worker=new Thread(this::loop,"DustinBot-AI");
        worker.start();
    }

    private void stopBot(){
        running.set(false);
        if(worker!=null) worker.interrupt();
        stopForeground(true);
        stopSelf();
    }

    private void loop(){
        final int wx=360, wy=1450, ax=650, ay=1350, lx=360, ly=1450;
        while(running.get()){
            try{
                BotAccessibilityService a=BotAccessibilityService.instance;
                if(a==null){ sleep(1500); continue; }

                switch(state){
                    case WALK:
                        // The game owns target-locking. We only move.
                        a.swipe(wx,wy,wx+220,wy,650);
                        sleep(1800);
                        state=State.ATTACK;
                        break;

                    case ATTACK:
                        // Attack the game's currently locked target.
                        a.tap(ax,ay);
                        sleep(650);
                        state=State.WAIT_DEAD;
                        break;

                    case WAIT_DEAD:
                        // No monster detection/selection. Allow the game's combat state to settle.
                        // Repeated attacks keep the current game-selected target under pressure.
                        a.tap(ax,ay);
                        sleep(900);
                        state=State.LOOT;
                        break;

                    case LOOT:
                        a.tap(lx,ly);
                        sleep(1200);
                        state=State.WALK;
                        break;
                }
            }catch(InterruptedException e){ return; }
            catch(Exception e){ sleep(1000); }
        }
    }

    private void sleep(long ms)throws InterruptedException{ Thread.sleep(ms); }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("dustinbot","DustinBot","low"));
        }
    }
    @Override public android.os.IBinder onBind(Intent i){ return null; }
}
