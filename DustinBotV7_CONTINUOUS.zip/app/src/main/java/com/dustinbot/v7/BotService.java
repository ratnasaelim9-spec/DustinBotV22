package com.dustinbot.v7;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class BotService extends Service {
    public static final String ACTION_START="START";
    public static final String ACTION_STOP="STOP";
    private final AtomicBoolean running=new AtomicBoolean(false);
    private Thread worker;

    @Override public int onStartCommand(Intent i,int flags,int id){
        if(i!=null && ACTION_STOP.equals(i.getAction())) stopBot();
        else if(i!=null && ACTION_START.equals(i.getAction())) startBot();
        return START_STICKY;
    }

    private void startBot(){
        if(running.getAndSet(true)) return;
        createChannel();
        startForeground(7001,new Notification.Builder(this,"dustinbot")
            .setContentTitle("DustinBot V7")
            .setContentText("เดิน + ตี + เก็บของ กำลังทำงาน")
            .setSmallIcon(android.R.drawable.ic_media_play).build());
        worker=new Thread(this::loop,"DustinBot-AI");
        worker.start();
    }

    private void stopBot(){
        running.set(false);
        if(worker!=null) worker.interrupt();
        stopForeground(true);
        stopSelf();
    }

    private void loop(){
        final int joystickX=360, joystickY=1450;
        final int attackX=650, attackY=1350;
        final int lootX=360, lootY=1450;
        boolean right=true;
        int cycle=0;

        while(running.get()){
            try{
                BotAccessibilityService a=BotAccessibilityService.instance;
                if(a==null){ Thread.sleep(1200); continue; }

                // เดินไปเรื่อย ๆ โดยให้เกมเป็นคนล็อกเป้า
                float x2=right ? joystickX+210 : joystickX-210;
                a.swipe(joystickX,joystickY,x2,joystickY,1100);

                // ตีเป้าหมายที่เกมล็อกไว้
                for(int i=0;i<3 && running.get();i++){
                    a.tap(attackX,attackY);
                    Thread.sleep(450);
                }

                // เก็บของ แล้วกลับไปเดินต่อ
                Thread.sleep(350);
                a.tap(lootX,lootY);
                Thread.sleep(650);

                cycle++;
                if(cycle%3==0) right=!right;
            }catch(InterruptedException e){ return; }
            catch(Exception e){
                try{ Thread.sleep(1000); }catch(Exception ignored){ return; }
            }
        }
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=getSystemService(NotificationManager.class);
            nm.createNotificationChannel(new NotificationChannel("dustinbot","DustinBot","low"));
        }
    }
    @Override public IBinder onBind(Intent i){ return null; }
}
