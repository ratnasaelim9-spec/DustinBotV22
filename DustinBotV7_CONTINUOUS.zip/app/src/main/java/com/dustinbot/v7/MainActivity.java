package com.dustinbot.v7;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.*;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        LinearLayout box=new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28,28,28,28);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        box.setBackgroundColor(Color.rgb(25,25,25));

        TextView title=new TextView(this);
        title.setText("DustinBot V7");
        title.setTextSize(28); title.setTextColor(Color.WHITE);
        title.setGravity(Gravity.CENTER);
        box.addView(title);

        TextView info=new TextView(this);
        info.setText("\nเดิน → เกมล็อกเป้าเอง → ตี → เก็บของ → เดินต่อ\n\nไม่ต้องหา Monster และไม่ต้องตั้ง Route");
        info.setTextSize(17); info.setTextColor(Color.LTGRAY);
        info.setGravity(Gravity.CENTER);
        box.addView(info);

        Button access=btn("1. เปิด ACCESSIBILITY");
        access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(access);

        Button overlay=btn("2. เปิด OVERLAY");
        overlay.setOnClickListener(v->startActivity(new Intent(
            Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
            android.net.Uri.parse("package:"+getPackageName()))));
        box.addView(overlay);

        Button start=btn("3. START BOT");
        start.setOnClickListener(v->{
            Intent i=new Intent(this,BotService.class);
            i.setAction(BotService.ACTION_START);
            startForegroundService(i);
        });
        box.addView(start);

        Button stop=btn("4. STOP BOT");
        stop.setOnClickListener(v->{
            Intent i=new Intent(this,BotService.class);
            i.setAction(BotService.ACTION_STOP);
            startService(i);
        });
        box.addView(stop);
        setContentView(box);
    }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); b.setTextSize(16); return b; }
}
