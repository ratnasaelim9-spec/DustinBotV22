package com.dustinbot.v7;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class BotAccessibilityService extends AccessibilityService {
    public static volatile BotAccessibilityService instance;

    @Override public void onServiceConnected(){ instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){}

    public boolean tap(float x,float y){
        if(instance==null) return false;
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,80)).build();
        return instance.dispatchGesture(g,null,null);
    }

    public boolean swipe(float x1,float y1,float x2,float y2,long duration){
        if(instance==null) return false;
        Path p=new Path(); p.moveTo(x1,y1); p.lineTo(x2,y2);
        GestureDescription g=new GestureDescription.Builder()
            .addStroke(new GestureDescription.StrokeDescription(p,0,duration)).build();
        return instance.dispatchGesture(g,null,null);
    }
}
