package com.dustinbot.v7;

import android.app.*;
import android.content.*;
import android.os.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class BotService extends Service {

    public static final String ACTION_START = "DUSTINBOT_START";
    public static final String ACTION_STOP  = "DUSTINBOT_STOP";

    private final AtomicBoolean running = new AtomicBoolean(false);
    private Thread worker;

    // These are percentages of the actual screen, not fixed 720x1594 pixels.
    private static final float MOVE_X = 0.50f;
    private static final float MOVE_Y = 0.92f;

    private static final float ATTACK_X = 0.90f;
    private static final float ATTACK_Y = 0.86f;

    private static final float LOOT_X = 0.50f;
    private static final float LOOT_Y = 0.78f;

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        if (intent != null) {
            String action = intent.getAction();

            if (ACTION_START.equals(action)) {
                startBot();
            } else if (ACTION_STOP.equals(action)) {
                stopBot();
            }
        }

        return START_STICKY;
    }

    private void startBot() {

        if (running.getAndSet(true)) return;

        createChannel();

        Notification notification =
                new Notification.Builder(this, "DUSTINBOT")
                        .setContentTitle("DustinBot V7")
                        .setContentText("เดิน + ตี + เก็บของ")
                        .setSmallIcon(android.R.drawable.ic_media_play)
                        .build();

        startForeground(7001, notification);

        worker = new Thread(this::runBot, "DustinBot-V7-AI");
        worker.start();
    }

    private void stopBot() {

        running.set(false);

        if (worker != null) {
            worker.interrupt();
            worker = null;
        }

        stopForeground(true);
        stopSelf();
    }

    private void runBot() {

        boolean directionRight = true;
        int cycle = 0;

        while (running.get()) {

            try {

                BotAccessibilityService bot =
                        BotAccessibilityService.instance;

                if (bot == null) {
                    Thread.sleep(1000);
                    continue;
                }

                android.util.DisplayMetrics dm =
                        getResources().getDisplayMetrics();

                float w = dm.widthPixels;
                float h = dm.heightPixels;

                float moveX = w * MOVE_X;
                float moveY = h * MOVE_Y;

                float attackX = w * ATTACK_X;
                float attackY = h * ATTACK_Y;

                float lootX = w * LOOT_X;
                float lootY = h * LOOT_Y;

                // WALK
                float endX;

                if (directionRight) {
                    endX = moveX + (w * 0.25f);
                } else {
                    endX = moveX - (w * 0.25f);
                }

                bot.swipe(
                        moveX,
                        moveY,
                        endX,
                        moveY,
                        900
                );

                Thread.sleep(700);

                // ATTACK
                // The game itself handles target locking.
                for (int i = 0; i < 3 && running.get(); i++) {

                    bot.tap(attackX, attackY);

                    Thread.sleep(500);
                }

                // WAIT
                Thread.sleep(700);

                // LOOT
                bot.tap(lootX, lootY);

                Thread.sleep(600);

                cycle++;

                if (cycle >= 3) {
                    directionRight = !directionRight;
                    cycle = 0;
                }

            } catch (InterruptedException e) {

                return;

            } catch (Exception e) {

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException ignored) {
                    return;
                }
            }
        }
    }

    private void createChannel() {

        if (Build.VERSION.SDK_INT >= 26) {

            NotificationManager manager =
                    getSystemService(NotificationManager.class);

            NotificationChannel channel =
                    new NotificationChannel(
                            "DUSTINBOT",
                            "DustinBot V7",
                            NotificationManager.IMPORTANCE_LOW
                    );

            manager.createNotificationChannel(channel);
        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
