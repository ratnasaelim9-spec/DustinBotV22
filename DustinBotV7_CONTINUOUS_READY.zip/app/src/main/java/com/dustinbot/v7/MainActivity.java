package com.dustinbot.v7;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.*;

public class MainActivity extends Activity {
    private EditText walkX, walkY, attackX, attackY, lootX, lootY, walkMs, attackMs, lootMs;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(28,28,28,28);

        TextView title = new TextView(this);
        title.setText("DustinBot V7\nAndroid OpenKore-style");
        title.setTextSize(24); title.setTextColor(Color.WHITE);
        box.setBackgroundColor(Color.rgb(25,25,25)); box.addView(title);

        box.addView(label("เดิน X")); walkX = field("360"); box.addView(walkX);
        box.addView(label("เดิน Y")); walkY = field("1450"); box.addView(walkY);
        box.addView(label("ตี X")); attackX = field("650"); box.addView(attackX);
        box.addView(label("ตี Y")); attackY = field("1350"); box.addView(attackY);
        box.addView(label("เก็บ X")); lootX = field("360"); box.addView(lootX);
        box.addView(label("เก็บ Y")); lootY = field("1450"); box.addView(lootY);
        box.addView(label("เวลาเดิน (ms)")); walkMs = field("1800"); box.addView(walkMs);
        box.addView(label("เวลาตี (ms)")); attackMs = field("650"); box.addView(attackMs);
        box.addView(label("เวลารอเก็บ (ms)")); lootMs = field("1200"); box.addView(lootMs);

        Button access = btn("1. เปิด Accessibility");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        box.addView(access);

        Button overlay = btn("2. เปิด Overlay");
        overlay.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                android.net.Uri.parse("package:" + getPackageName()))));
        box.addView(overlay);

        Button save = btn("บันทึกค่าตั้งต้น");
        save.setOnClickListener(v -> save());
        box.addView(save);

        Button start = btn("START BOT");
        start.setOnClickListener(v -> {
            save();
            Intent i = new Intent(this, BotService.class);
            i.setAction(BotService.ACTION_START);
            startForegroundService(i);
        });
        box.addView(start);

        Button stop = btn("STOP BOT");
        stop.setOnClickListener(v -> {
            Intent i = new Intent(this, BotService.class);
            i.setAction(BotService.ACTION_STOP);
            startService(i);
        });
        box.addView(stop);

        setContentView(box);
        load();
    }

    private TextView label(String s){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.LTGRAY); t.setTextSize(14); return t; }
    private EditText field(String s){ EditText e=new EditText(this); e.setText(s); e.setTextColor(Color.WHITE); e.setInputType(2); return e; }
    private Button btn(String s){ Button b=new Button(this); b.setText(s); return b; }

    private void save(){
        getPreferences(0).edit()
            .putInt("walkX", n(walkX)).putInt("walkY", n(walkY))
            .putInt("attackX", n(attackX)).putInt("attackY", n(attackY))
            .putInt("lootX", n(lootX)).putInt("lootY", n(lootY))
            .putLong("walkMs", ln(walkMs,1800)).putLong("attackMs", ln(attackMs,650))
            .putLong("lootMs", ln(lootMs,1200)).apply();
    }
    private void load(){
        android.content.SharedPreferences p=getPreferences(0);
        walkX.setText(""+p.getInt("walkX",360)); walkY.setText(""+p.getInt("walkY",1450));
        attackX.setText(""+p.getInt("attackX",650)); attackY.setText(""+p.getInt("attackY",1350));
        lootX.setText(""+p.getInt("lootX",360)); lootY.setText(""+p.getInt("lootY",1450));
        walkMs.setText(""+p.getLong("walkMs",1800)); attackMs.setText(""+p.getLong("attackMs",650)); lootMs.setText(""+p.getLong("lootMs",1200));
    }
    private int n(EditText e){ try{return Integer.parseInt(e.getText().toString());}catch(Exception x){return 0;} }
    private long ln(EditText e,long d){ try{return Long.parseLong(e.getText().toString());}catch(Exception x){return d;} }
}
