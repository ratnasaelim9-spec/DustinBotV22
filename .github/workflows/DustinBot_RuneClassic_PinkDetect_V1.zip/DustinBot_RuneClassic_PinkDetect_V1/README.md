# DustinBot Rune Classic — Pink Detect V1

This is a real-screen detector prototype, not OCR and not a monster-name database.
It captures the Rune Classic screen through MediaProjection, searches for pink/saturated regions consistent with a Poring, and uses Android Accessibility gesture dispatch to tap the detected center.

## Test order on the phone
1. Install APK.
2. Enable Accessibility for DustinBot.
3. Grant screen capture permission.
4. Open Rune Classic and put a Poring clearly on screen.
5. Press START DETECT.

This version deliberately does only one thing: detect/tap a Poring-like pink target. It does NOT claim to navigate, attack, or loot yet. Those are added only after the detection/tap test works.
