package com.dustinbot.pinkdetect;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Bundle;
import android.view.accessibility.AccessibilityEvent;

public class BotAccessibilityService extends AccessibilityService {
    public static volatile BotAccessibilityService instance;
    @Override public void onServiceConnected(){ super.onServiceConnected(); instance=this; }
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){ if(instance==this) instance=null; }
    public static boolean tap(float x,float y){
        BotAccessibilityService s=instance; if(s==null) return false;
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription g=new GestureDescription.Builder().addStroke(new GestureDescription.StrokeDescription(p,0,60)).build();
        return s.dispatchGesture(g,null,null);
    }
}
