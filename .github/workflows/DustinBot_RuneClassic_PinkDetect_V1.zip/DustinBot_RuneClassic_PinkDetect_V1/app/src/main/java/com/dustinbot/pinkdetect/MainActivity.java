package com.dustinbot.pinkdetect;

import android.app.*;import android.content.*;import android.media.projection.MediaProjectionManager;import android.os.*;import android.provider.Settings;import android.text.method.ScrollingMovementMethod;import android.view.*;import android.widget.*;

public class MainActivity extends Activity {
    static final int REQ_CAPTURE=501;
    TextView status; EditText minPixels, satMin, hueMin, hueMax; Button capture,start,stop;
    @Override public void onCreate(Bundle b){super.onCreate(b); LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(24,24,24,24);
      TextView title=new TextView(this);title.setText("DustinBot — Poring Pink Detector V1");title.setTextSize(22);l.addView(title);
      TextView info=new TextView(this);info.setText("ตรวจจับสีชมพูของ Poring จากภาพหน้าจอจริง แล้วแสดงพิกัด/แตะเป้าหมาย\nไม่ใช้ OCR และไม่ใช้ฐานข้อมูลชื่อมอนสเตอร์");l.addView(info);
      Button acc=new Button(this);acc.setText("1) เปิด Accessibility");acc.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));l.addView(acc);
      capture=new Button(this);capture.setText("2) อนุญาตจับภาพหน้าจอ");capture.setOnClickListener(v->{MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);startActivityForResult(m.createScreenCaptureIntent(),REQ_CAPTURE);});l.addView(capture);
      start=new Button(this);start.setText("3) START DETECT");start.setOnClickListener(v->{if(CaptureService.start(this))status.setText("กำลังตรวจจับ...\nรอ Poring บนหน้าจอ");else status.setText("ยังไม่ได้อนุญาตจับหน้าจอ");});l.addView(start);
      stop=new Button(this);stop.setText("STOP");stop.setOnClickListener(v->CaptureService.stop(this));l.addView(stop);
      status=new TextView(this);status.setText("สถานะ: ยังไม่เริ่ม");status.setTextSize(16);status.setMovementMethod(new ScrollingMovementMethod());l.addView(status,new LinearLayout.LayoutParams(-1,0,1));
      setContentView(l);
    }
    @Override protected void onActivityResult(int r,int c,Intent d){super.onActivityResult(r,c,d);if(r==REQ_CAPTURE&&c==RESULT_OK&&d!=null){CaptureService.pendingResult=c;CaptureService.pendingData=d;status.setText("อนุญาตจับภาพแล้ว — กด START DETECT");}}
}
