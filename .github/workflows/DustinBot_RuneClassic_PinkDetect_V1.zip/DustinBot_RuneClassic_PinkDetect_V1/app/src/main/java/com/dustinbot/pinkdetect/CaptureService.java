package com.dustinbot.pinkdetect;

import android.app.*;import android.content.*;import android.content.pm.ServiceInfo;import android.graphics.*;import android.hardware.display.*;import android.media.*;import android.media.projection.*;import android.os.*;import java.util.*;import java.nio.*;

public class CaptureService extends Service {
 static Intent pendingData; static int pendingResult; static volatile boolean running;
 MediaProjection projection; ImageReader reader; HandlerThread ht; Handler h; long lastTap=0;
 public static boolean start(Context c){if(pendingData==null)return false;Intent i=new Intent(c,CaptureService.class);i.setAction("START");c.startForegroundService(i);return true;}
 public static void stop(Context c){c.stopService(new Intent(c,CaptureService.class));}
 @Override public int onStartCommand(Intent intent,int flags,int id){
   if(Build.VERSION.SDK_INT>=29)startForeground(9,notification(),ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION); else startForeground(9,notification());
   if(projection==null) begin(); return START_NOT_STICKY;
 }
 Notification notification(){NotificationChannel ch=new NotificationChannel("bot","DustinBot",NotificationManager.IMPORTANCE_LOW);((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(ch);return new Notification.Builder(this,"bot").setContentTitle("DustinBot").setContentText("กำลังตรวจจับ Poring").setSmallIcon(android.R.drawable.ic_menu_search).build();}
 void begin(){projection=((MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE)).getMediaProjection(pendingResult,pendingData);DisplayMetrics dm=getResources().getDisplayMetrics();int w=dm.widthPixels,hg=dm.heightPixels;reader=ImageReader.newInstance(w,hg,PixelFormat.RGBA_8888,2);projection.createVirtualDisplay("DustinBot",w,hg,dm.densityDpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,null);ht=new HandlerThread("detect");ht.start();h=new Handler(ht.getLooper());running=true;reader.setOnImageAvailableListener(r->{Image im=null;try{im=r.acquireLatestImage();if(im!=null)detect(im);}finally{if(im!=null)im.close();}},h);}
 void detect(Image image){
   Image.Plane p=image.getPlanes()[0];ByteBufferHack b=new ByteBufferHack(p.getBuffer());int pw=image.getWidth(),ph=image.getHeight();int stride=p.getRowStride(),pix=p.getPixelStride();
   int step=4; int minX=pw,minY=ph,maxX=0,maxY=0,count=0;
   for(int y=ph/5;y<ph*4/5;y+=step){for(int x=0;x<pw;x+=step){int pos=y*stride+x*pix;int rr=b.u8(pos),gg=b.u8(pos+1),bb=b.u8(pos+2);int mx=Math.max(rr,Math.max(gg,bb)),mn=Math.min(rr,Math.min(gg,bb));int sat=mx-mn;
      // Poring-like pink: red dominant, moderately saturated, bright enough. UI/top/bottom are excluded.
      if(rr>145 && rr>gg*1.18 && rr>bb*1.12 && sat>35){count++;if(x<minX)minX=x;if(y<minY)minY=y;if(x>maxX)maxX=x;if(y>maxY)maxY=y;}
   }}
   int bw=maxX-minX+1,bh=maxY-minY+1; if(count<35||bw<18||bh<12||bw>pw/2||bh>ph/2)return;
   // reject very thin bars / giant UI regions
   float ratio=bw/(float)bh;if(ratio<0.45f||ratio>3.0f)return;
   float cx=(minX+maxX)/2f,cy=(minY+maxY)/2f;
   if(System.currentTimeMillis()-lastTap>1200){lastTap=System.currentTimeMillis();BotAccessibilityService.tap(cx,cy);}
 }
 static class ByteBufferHack{java.nio.ByteBuffer b;ByteBufferHack(java.nio.ByteBuffer b){this.b=b;}int u8(int p){if(p<0||p>=b.limit())return 0;return b.get(p)&255;}}
 @Override public void onDestroy(){running=false;try{if(reader!=null)reader.close();if(projection!=null)projection.stop();}catch(Exception e){}if(ht!=null)ht.quitSafely();super.onDestroy();}
 @Override public android.os.IBinder onBind(Intent i){return null;}
}
