# DustinBot V6

Android screen-based bot prototype for a game/server where bot use is permitted.

Flow:
SEARCH -> TARGET -> ATTACK -> LOOT -> SEARCH

Uses Android Accessibility gestures and MediaProjection screen capture.
No packet injection, client modification, or anti-cheat bypass.

GitHub Actions builds `DustinBot-V6-APK`.
